package com.example.demoameyapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourierDetailsServiceImpl implements CourierDetailsService {


   private final CourierRepository courierRepository;


    @Autowired
    public CourierDetailsServiceImpl(final CourierRepository courierRepository  ) {
        this.courierRepository = courierRepository;
    }

    @Override
    public List<CourierDetails> getListOfCourierDetails(final String courierId) {
        List<CourierDetails> courierDetailsList = courierRepository.getListOfCourierDetails(courierId);
        return courierDetailsList;
     }
}
