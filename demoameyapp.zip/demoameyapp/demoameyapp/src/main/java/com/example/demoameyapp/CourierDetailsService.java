package com.example.demoameyapp;

import com.example.demoameyapp.CourierDetails;

import java.util.List;

public interface CourierDetailsService {

    List<CourierDetails> getListOfCourierDetails(String courierId);
}
