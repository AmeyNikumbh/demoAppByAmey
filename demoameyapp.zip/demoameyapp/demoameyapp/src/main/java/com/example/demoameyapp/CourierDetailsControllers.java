package com.example.demoameyapp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
public class CourierDetailsControllers implements CourierDetailsContract {

    private final CourierDetailsService courierDetailsService;
    private static final Logger log = LoggerFactory.getLogger(CourierDetailsControllers.class);

    @Autowired
    public CourierDetailsControllers(final CourierDetailsService courierDetailsService) {
        this.courierDetailsService = courierDetailsService;
    }

    @Override
    @GetMapping(value = "/courier/{courierId}", produces = { APPLICATION_JSON_VALUE })
    public ResponseEntity<CourierDetailsResponse> getListOfCourierDetails(@PathVariable(name = "courierId") String courierId) {

        log.info("You are in controller");

        List<CourierDetails> courierDetailsList = courierDetailsService.getListOfCourierDetails(courierId);
        return new ResponseEntity<>(CourierDetailsResponse.builder().courierDetailsList(courierDetailsList).build(), HttpStatus.ACCEPTED);    }
}
