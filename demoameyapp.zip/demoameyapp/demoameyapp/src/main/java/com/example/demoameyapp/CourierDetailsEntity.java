package com.example.demoameyapp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "CR", schema = "PNET")
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Getter
@Setter
public class CourierDetailsEntity {

    @Id
    @Column(name="CR_ID")
    private String crId;

    @Column(name = "CR_FRST_NME")
    private String crFirstName;

    @Column(name = "CR_LAST_NME")
    private String crLastName;

    @Column(name = "CR_LD_TMESTP")
    private LocalDateTime crTimeStp;
}
