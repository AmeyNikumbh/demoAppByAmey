package com.example.demoameyapp;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;



import java.util.List;


@Repository
public interface CourierRepository extends CrudRepository<CourierDetailsEntity,String> {

    @Query(value= "SELECT e.CR_FRST_NME,e.CR_LAST_NME,e.CR_LD_TMESTP from PNET.CR e where e.CR_ID = :courierId", nativeQuery = true)
    public List<CourierDetails> getListOfCourierDetails(@Param("courierId") String courierId);

}
