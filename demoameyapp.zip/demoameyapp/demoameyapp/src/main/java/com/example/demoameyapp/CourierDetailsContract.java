package com.example.demoameyapp;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


public interface CourierDetailsContract {

    @GetMapping(value = "/courier/{courierId}", produces = { APPLICATION_JSON_VALUE })
    ResponseEntity <CourierDetailsResponse> getListOfCourierDetails(@PathVariable(name = "courierId") String courierId);
}
