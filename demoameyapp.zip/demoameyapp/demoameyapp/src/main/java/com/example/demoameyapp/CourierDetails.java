package com.example.demoameyapp;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CourierDetails {

    private String courierId;
    private String courierFirstName;
    private String courierLastName;
    private String courierTimeStamp;

}
